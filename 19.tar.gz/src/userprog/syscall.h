#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

/* Process identifier type. */
typedef int pid_t;

void syscall_init (void);

#endif /* userprog/syscall.h */
